import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RegisterService } from '../../services/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  providers: [RegisterService]
})
export class RegisterComponent implements OnInit {

  
  public province: any;
  public canton: any;
  public district: any;

  constructor(
    private _registerService: RegisterService
  ){
   }

  ngOnInit(): void {
  }

  getProvince(){
    this.province = false;
    this._registerService.getProvince().subscribe(
      result => {
        this.province = result.data;
      },
      err => {
        console.log(<any>err);
      }
    );
  }

  education_level;
  exam_title;
  gender;
  degreeTitleList = [];
  selected = 'option2';

  educationInfo = {
    aa: 'Secondary',
    bb: 'SSC',
    cc: 'Male'
  }

  genderList = ['Male', 'Female']

  educationList: any = [
    {
      'educationLevelName': 'PSC/5 pass',
      degreeTitleList: [
        'PSC', '5 Pass', 'Other',
      ]
    },
    {
      'educationLevelName': 'JSC/JDC/8 pass',
      degreeTitleList: [
        'JSC', '8 Pass', 'Other'
      ]
    },
    {
      'educationLevelName': 'Secondary',
      degreeTitleList: [
        'SSC', 'O Level', 'Other',
      ]
    }
  ];


  editInfo(educationInfo) {
    this.education_level = educationInfo.aa;
    this.exam_title = educationInfo.bb;
    this.gender = educationInfo.cc;
    this.educationLevelChangeAction(this.education_level);
  }

  educationLevelChangeAction(education) {
    this.exam_title="";
    let dropDownData = this.educationList.find((data: any) => data.educationLevelName === education);
    if (dropDownData) {
      this.degreeTitleList = dropDownData.degreeTitleList;
      if(this.degreeTitleList){
        this.exam_title=this.degreeTitleList[0];
      }
      
    } else {
      this.degreeTitleList = [];
    }

  }


}
